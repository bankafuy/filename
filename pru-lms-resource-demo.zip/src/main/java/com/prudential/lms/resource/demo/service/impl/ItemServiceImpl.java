package com.prudential.lms.resource.demo.service.impl;

import java.util.LinkedList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.lms.resource.demo.dto.ItemDTO;
import com.prudential.lms.resource.demo.model.Category;
import com.prudential.lms.resource.demo.model.Item;
import com.prudential.lms.resource.demo.model.QCategory;
import com.prudential.lms.resource.demo.model.QItem;
import com.prudential.lms.resource.demo.repository.CategoryRepository;
import com.prudential.lms.resource.demo.repository.ItemRepository;
import com.prudential.lms.resource.demo.service.ItemService;
import com.querydsl.core.types.dsl.BooleanExpression;

@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	private ItemRepository repo;
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@Autowired
	private ModelMapper autoMapper;

	@Override
	public List<ItemDTO> getData(ItemDTO keyword) {
		try {
			BooleanExpression predicate = QItem.item.id.isNotNull();
			
			if(keyword != null) {
				if(keyword.getId() != null) {
					predicate = predicate.and(QItem.item.id.eq(keyword.getId()));
				}
				
				if(keyword.getCode() != null) {
					predicate = predicate.and(QItem.item.code.containsIgnoreCase(keyword.getCode()));
				}
				
				if(keyword.getName() != null) {
					predicate = predicate.and(QItem.item.name.containsIgnoreCase(keyword.getName()));
				}
				
				if(keyword.getCategoryName() != null) {
					BooleanExpression predicateCategory = QCategory.category.name.containsIgnoreCase(keyword.getCategoryName());
					
					Iterable<Category> categoryList = categoryRepo.findAll(predicateCategory);
					
					if(categoryList != null) {
						List<String> listCategoryCode = new LinkedList<>();
						categoryList.forEach(category -> {
							listCategoryCode.add(category.getCode());
						});

						predicate = predicate.and(QItem.item.categoryCode.in(listCategoryCode));
					}
					
				}
			}
			
			Iterable<Item> dataList = repo.findAll(predicate);
			List<ItemDTO> results = new LinkedList<>();
			if(dataList != null) {
				for(Item data : dataList) {
					ItemDTO dto = autoMapper.map(data, ItemDTO.class);
					
					if(data.getCategoryCode() != null) {
						BooleanExpression predicateCategory = QCategory.category.code.equalsIgnoreCase(data.getCategoryCode());
						
						Category category = categoryRepo.findOne(predicateCategory);
						
						if(category != null) {
							dto.setCategoryName(category.getName());
						}
					}
					
					results.add(dto);
				}
			}

			return results;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public ItemDTO getDataById(Long id) {
		try {
			if(id != null) {
				Item data = repo.findOne(id);
				if(data != null) {
					ItemDTO result = autoMapper.map(data, ItemDTO.class);
					
					if(data.getCategoryCode() != null) {
						BooleanExpression predicate = QCategory.category.code.equalsIgnoreCase(data.getCategoryCode());
						
						Category category = categoryRepo.findOne(predicate);
						
						if(category != null) {
							result.setCategoryName(category.getName());
						}

					}
					
					return result;
				}
			}
			
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public ItemDTO insert(ItemDTO dto) {
		try {
			Item data = new Item();

			data.setCode(dto.getCode());
			data.setName(dto.getName());

			if(dto.getCategoryName() != null) {
				BooleanExpression predicate = QCategory.category.name.equalsIgnoreCase(dto.getCategoryName());
				
				Category category = categoryRepo.findOne(predicate);
				
				if(category != null) {
					data.setCategoryCode(category.getCode());
				}
			}
			
			Item saved = repo.save(data);
			
			ItemDTO result = autoMapper.map(saved, ItemDTO.class);
			
			
			
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public ItemDTO update(ItemDTO dto) {
		try {
			if(dto.getId() != null) {
				Item data = repo.findOne(dto.getId());
				data.setName(dto.getName());

				if(dto.getCategoryName() != null) {
					BooleanExpression predicate = QCategory.category.name.equalsIgnoreCase(dto.getCategoryName());
					
					Category category = categoryRepo.findOne(predicate);
					
					if(category != null) {
						data.setCategoryCode(category.getCode());
					}
				}
				
				Item saved = repo.save(data);
				
				ItemDTO result = autoMapper.map(saved, ItemDTO.class);
				
				return result;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public Boolean delete(Long id) {
		try {
			if(id != null) {
				Item data = repo.findOne(id);
				if(data != null) {
					repo.delete(data);
					
					boolean exists = repo.exists(id);
					return !exists;
				}
			}
			
			return null;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


}
