package com.prudential.lms.resource.demo.service.impl;

import java.util.LinkedList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.lms.resource.demo.dto.CategoryDTO;
import com.prudential.lms.resource.demo.model.Category;
import com.prudential.lms.resource.demo.model.QCategory;
import com.prudential.lms.resource.demo.repository.CategoryRepository;
import com.prudential.lms.resource.demo.service.CategoryService;
import com.querydsl.core.types.dsl.BooleanExpression;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	private CategoryRepository repo;
	
	@Autowired
	private ModelMapper autoMapper;

	@Override
	public List<CategoryDTO> getData(CategoryDTO keyword) {
		try {
			BooleanExpression predicate = QCategory.category.id.isNotNull();
			
			if(keyword != null) {
				if(keyword.getId() != null) {
					predicate = predicate.and(QCategory.category.id.eq(keyword.getId()));
				}
				
				if(keyword.getCode() != null) {
					predicate = predicate.and(QCategory.category.code.containsIgnoreCase(keyword.getCode()));
				}
				
				if(keyword.getName() != null) {
					predicate = predicate.and(QCategory.category.name.containsIgnoreCase(keyword.getName()));
				}
			}
			
			Iterable<Category> dataList = repo.findAll(predicate);
			List<CategoryDTO> results = new LinkedList<>();
			if(dataList != null) {
				for(Category data : dataList) {
					CategoryDTO dto = autoMapper.map(data, CategoryDTO.class);
					results.add(dto);
				}
			}

			return results;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public CategoryDTO getDataById(Long id) {
		try {
			if(id != null) {
				Category data = repo.findOne(id);
				if(data != null) {
					CategoryDTO result = autoMapper.map(data, CategoryDTO.class);
					
					return result;
				}
			}
			
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public CategoryDTO insert(CategoryDTO dto) {
		try {
			Category data = new Category();

			data.setCode(dto.getCode());
			data.setName(dto.getName());
			
			Category saved = repo.save(data);
			
			CategoryDTO result = autoMapper.map(saved, CategoryDTO.class);
			
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public CategoryDTO update(CategoryDTO dto) {
		try {
			if(dto.getId() != null) {
				Category data = repo.findOne(dto.getId());
				data.setName(dto.getName());
				
				Category saved = repo.save(data);
				
				CategoryDTO result = autoMapper.map(saved, CategoryDTO.class);
				
				return result;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public Boolean delete(Long id) {
		try {
			if(id != null) {
				Category data = repo.findOne(id);
				if(data != null) {
					repo.delete(data);
					
					boolean exists = repo.exists(id);
					return !exists;
				}
			}
			
			return null;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
