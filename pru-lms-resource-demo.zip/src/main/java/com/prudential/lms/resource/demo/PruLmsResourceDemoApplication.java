package com.prudential.lms.resource.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruLmsResourceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruLmsResourceDemoApplication.class, args);
		System.out.println("Service started.");
	}
}
