package com.prudential.lms.resource.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.lms.resource.demo.dto.CategoryDTO;
import com.prudential.lms.resource.demo.service.CategoryService;

@RestController
@RequestMapping("/categories")
public class CategoryController {

	@Autowired
	private CategoryService service;
	
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public Object getAll(@RequestBody(required = true) CategoryDTO keyword) {
		try {
			final List<CategoryDTO> dataList = service.getData(keyword);
			return new ResponseEntity<>(dataList, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@RequestMapping(value = "", method = RequestMethod.POST)
	public Object post(@RequestBody(required = true) CategoryDTO dto) {
		try {
			final CategoryDTO data = service.insert(dto);
			
			if(data != null) {
				return new ResponseEntity<>(data, HttpStatus.OK);
			}
			
			return new ResponseEntity<>("Failed to insert data.", HttpStatus.BAD_REQUEST);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Object put(@PathVariable("id") Long id, @RequestBody(required = true) CategoryDTO dto) {
		try {
			dto.setId(id);
			final CategoryDTO data = service.update(dto);

			if(data != null) {
				return new ResponseEntity<>(data, HttpStatus.OK);
			}
			
			return new ResponseEntity<>("Failed to update data.", HttpStatus.BAD_REQUEST);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public Object delete(@PathVariable("id") Long id) {
		try {
			Boolean delete = service.delete(id);

			if(delete != null) {
				return new ResponseEntity<>(String.format("Deleted: %s", delete), HttpStatus.OK);
			}
			
			return new ResponseEntity<>("Failed to delete data.", HttpStatus.BAD_REQUEST);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Object getById(@PathVariable("id") Long id) {
		try {
			final CategoryDTO data = service.getDataById(id);
			
			if(data != null) {
				return new ResponseEntity<>(data, HttpStatus.OK);
			}
			
			return new ResponseEntity<>("Cannot get data.", HttpStatus.NOT_FOUND);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
