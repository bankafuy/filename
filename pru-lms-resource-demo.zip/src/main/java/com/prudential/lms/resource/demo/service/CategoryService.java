package com.prudential.lms.resource.demo.service;

import java.util.List;

import com.prudential.lms.resource.demo.dto.CategoryDTO;

public interface CategoryService {
	List<CategoryDTO> getData(CategoryDTO keyword);
	CategoryDTO getDataById(Long id);
	CategoryDTO insert(CategoryDTO dto);
	CategoryDTO update(CategoryDTO dto);
	Boolean delete(Long id);
}
