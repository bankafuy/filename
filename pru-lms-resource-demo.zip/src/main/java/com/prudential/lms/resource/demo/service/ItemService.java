package com.prudential.lms.resource.demo.service;

import java.util.List;

import com.prudential.lms.resource.demo.dto.ItemDTO;

public interface ItemService {
	List<ItemDTO> getData(ItemDTO keyword);
	ItemDTO getDataById(Long id);
	ItemDTO insert(ItemDTO dto);
	ItemDTO update(ItemDTO dto);
	Boolean delete(Long id);
}
